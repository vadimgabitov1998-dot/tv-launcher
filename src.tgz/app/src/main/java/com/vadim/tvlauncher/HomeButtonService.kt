package com.vadim.tvlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * На Google TV нельзя просто выбрать другой главный экран. Эта служба замечает,
 * что открылся стандартный экран Google TV (кнопка «Домой»), и сразу открывает наш лаунчер.
 * Служба ничего не читает с экрана и никуда не передаёт.
 */
class HomeButtonService : AccessibilityService() {
    private val stock = setOf("com.google.android.apps.tv.launcherx", "com.google.android.tvlauncher")
    private var last = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || event.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in stock) return
        if (!Prefs(this).homeOverride) return
        val now = System.currentTimeMillis()
        if (now - last < 400) return
        last = now
        val i = Intent(this, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        )
        try { startActivity(i) } catch (e: Exception) { }
    }

    override fun onInterrupt() {}
}
