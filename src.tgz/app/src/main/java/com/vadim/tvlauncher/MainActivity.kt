package com.vadim.tvlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.tv.TvContract
import android.media.tv.TvInputManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextClock
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

fun loadWallpaper(iv: ImageView, ctx: Context, key: String) {
    if (key == "custom") {
        val f = File(ctx.filesDir, "custom_wall")
        if (f.exists()) {
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(f.path, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= 1920) sample *= 2
            val bmp = BitmapFactory.decodeFile(f.path, BitmapFactory.Options().apply { inSampleSize = sample })
            if (bmp != null) { iv.setImageBitmap(bmp); return }
        }
    }
    iv.setImageResource(Walls.res(key))
}

fun styleClock(tv: TextView, prefs: Prefs, size: Number) {
    tv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, Ui.pxf(size))
    tv.letterSpacing = -0.035f
    when (prefs.clockStyle) {
        "glow" -> {
            tv.typeface = Ui.font(500)
            tv.setTextColor(Color.WHITE)
            tv.setShadowLayer(Ui.pxf(45), 0f, 0f, Walls.glow(prefs.wallpaper))
        }
        "thin" -> {
            tv.typeface = Ui.font(200)
            tv.setTextColor(Color.WHITE)
            tv.setShadowLayer(0f, 0f, 0f, 0)
        }
        else -> {
            tv.typeface = Ui.font(600)
            tv.setTextColor(Ui.white(228))
            tv.setShadowLayer(Ui.pxf(30), 0f, Ui.pxf(10), Ui.black(80))
        }
    }
}

fun dateText(): String {
    val s = SimpleDateFormat("EEEE, d MMMM", Locale("ru")).format(Date())
    return s.replaceFirstChar { it.uppercase() }
}

class MainActivity : Activity() {
    private lateinit var prefs: Prefs
    private val handler = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private var apps: List<AppEntry> = emptyList()

    private lateinit var root: FrameLayout
    private lateinit var wallView: ImageView
    private lateinit var dateView: TextView
    private lateinit var clockView: TextClock
    private lateinit var weatherView: TextView
    private lateinit var recentsBox: LinearLayout
    private lateinit var recentsRow: LinearLayout
    private lateinit var dockBox: LinearLayout
    private lateinit var dockRow: LinearLayout
    private lateinit var dockLabel: TextView
    private lateinit var nightView: View
    private lateinit var ccButton: View
    private lateinit var allButton: View

    private var ccPanel: View? = null
    private var appsPanel: View? = null
    private var saverView: View? = null
    private var appsGrid: LinearLayout? = null
    private var showHidden = false
    private var filter = ""
    private var focusPkg: String? = null

    // ---------------------------------------------------------------- lifecycle

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.init(this)
        prefs = Prefs(this)
        window.addFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN)
        buildUi()
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        applyLook()
        reloadApps()
        updateWeather(false)
        handler.removeCallbacks(ticker)
        handler.post(ticker)
        resetIdle()
    }

    override fun onPause() {
        super.onPause()
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(idleRunnable)
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Повторное нажатие «Домой» на главном экране — закрываем все окна.
        hideSaver()
        closeOverlays()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (saverView != null) { hideSaver(); return }
        if (ccPanel != null || appsPanel != null) { closeOverlays(); return }
        // На главном экране «Назад» ничего не делает.
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (saverView != null) {
            if (event.action == KeyEvent.ACTION_UP) hideSaver()
            return true
        }
        resetIdle()
        return super.dispatchKeyEvent(event)
    }

    private val ticker = object : Runnable {
        override fun run() {
            dateView.text = dateText()
            nightView.visibility = if (prefs.isNightNow()) View.VISIBLE else View.GONE
            updateWeather(false)
            handler.postDelayed(this, 30_000)
        }
    }

    private val idleRunnable = Runnable { showSaver() }

    private fun resetIdle() {
        handler.removeCallbacks(idleRunnable)
        val m = prefs.saverMin
        if (m > 0) handler.postDelayed(idleRunnable, m * 60_000L)
    }

    // ---------------------------------------------------------------- main screen

    private fun buildUi() {
        root = FrameLayout(this)

        wallView = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wallView, Ui.frame(Ui.MATCH, Ui.MATCH))

        val shade = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.TOP_BOTTOM,
                intArrayOf(Ui.black(40), 0, 0, Ui.black(110))
            )
        }
        root.addView(shade, Ui.frame(Ui.MATCH, Ui.MATCH))

        // Дата, часы, погода
        val top = Ui.vbox(this).apply { gravity = Gravity.CENTER_HORIZONTAL }
        dateView = Ui.text(this, dateText(), 36, 600, Ui.white(235))
        clockView = TextClock(this).apply { includeFontPadding = false }
        weatherView = Ui.text(this, prefs.city, 30, 500, Ui.white(230))
        top.addView(dateView, Ui.lin(Ui.WRAP, Ui.WRAP))
        top.addView(clockView, Ui.lin(Ui.WRAP, Ui.WRAP).m(t = 4, b = 8))
        top.addView(weatherView, Ui.lin(Ui.WRAP, Ui.WRAP))
        root.addView(top, Ui.frame(Ui.MATCH, Ui.WRAP, Gravity.TOP).m(t = 96))

        // Кнопка «Пункт управления»
        ccButton = FrameLayout(this).apply {
            background = Ui.states(Ui.glass(42), Ui.rect(42, Ui.white(110), Ui.white(220), 2.5))
            addView(Ui.icon(context, R.drawable.ic_cc, 38), Ui.frame(Ui.px(38), Ui.px(38), Gravity.CENTER))
            contentDescription = "Пункт управления"
            Ui.bindFocus(this, 1.1f)
            setOnClickListener { openCC() }
        }
        root.addView(ccButton, Ui.frame(Ui.px(84), Ui.px(84), Gravity.TOP or Gravity.END).m(t = 64, r = 72))

        // Недавние
        recentsBox = Ui.vbox(this, 14).apply { gravity = Gravity.CENTER_HORIZONTAL }
        recentsBox.addView(Ui.text(this, "Недавние", 22, 600, Ui.white(215)), Ui.lin(Ui.WRAP, Ui.WRAP))
        recentsRow = Ui.hbox(this, 16)
        recentsBox.addView(recentsRow, Ui.lin(Ui.WRAP, Ui.WRAP))
        root.addView(recentsBox, Ui.frame(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).m(b = 222))

        // Dock
        dockBox = Ui.hbox(this, 20).apply {
            background = Ui.glass(40)
            pad(20, 16)
            clipChildren = false
            clipToPadding = false
        }
        dockRow = Ui.hbox(this, 20).apply { clipChildren = false; clipToPadding = false }
        dockBox.addView(dockRow, Ui.lin(Ui.WRAP, Ui.WRAP))
        dockBox.addView(View(this).apply { background = Ui.rect(1, Ui.white(80)) }, Ui.lin(Ui.px(2), Ui.px(72)))
        allButton = FrameLayout(this).apply {
            background = Ui.states(Ui.rect(22, Ui.white(56)), Ui.rect(22, Ui.white(120), Ui.white(230), 3))
            addView(Ui.icon(context, R.drawable.ic_grid, 44), Ui.frame(Ui.px(44), Ui.px(44), Gravity.CENTER))
            contentDescription = "Все приложения"
            Ui.bindFocus(this, if (prefs.zoom) 1.15f else 1f, if (prefs.zoom) 10 else 0) { has ->
                if (has) showDockLabel(this, "Все приложения") else hideDockLabel()
            }
            setOnClickListener { openApps() }
        }
        dockBox.addView(allButton, Ui.lin(Ui.px(97), Ui.px(97)))
        root.clipChildren = false
        root.addView(dockBox, Ui.frame(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).m(b = 56))

        dockLabel = Ui.text(this, "", 24, 600).apply {
            background = Ui.rect(22, Color.argb(170, 22, 22, 38), Ui.white(60))
            pad(20, 10)
            visibility = View.INVISIBLE
        }
        root.addView(dockLabel, Ui.frame(Ui.WRAP, Ui.WRAP))

        nightView = View(this).apply {
            setBackgroundColor(Color.argb(115, 40, 18, 0))
            visibility = View.GONE
            isFocusable = false
        }
        root.addView(nightView, Ui.frame(Ui.MATCH, Ui.MATCH))
    }

    private fun applyLook() {
        val key = prefs.wallpaper
        loadWallpaper(wallView, this, key)
        val fmt = if (prefs.h24) "HH:mm" else "h:mm"
        clockView.format24Hour = fmt
        clockView.format12Hour = fmt
        styleClock(clockView, prefs, if (prefs.clockStyle == "thin") 280 else 260)
        dateView.text = dateText()
        nightView.visibility = if (prefs.isNightNow()) View.VISIBLE else View.GONE
        showWeather()
    }

    private fun showWeather() {
        val w = prefs.weather
        weatherView.text = if (w.isEmpty()) prefs.city else "${prefs.city}  •  $w"
    }

    private fun updateWeather(force: Boolean) {
        val now = System.currentTimeMillis()
        if (!force && now - prefs.weatherAt < 30 * 60_000L) return
        prefs.weatherAt = now
        val lat = prefs.lat
        val lon = prefs.lon
        bg.execute {
            val w = Weather.fetch(lat, lon)
            handler.post {
                if (w != null) prefs.weather = w else prefs.weatherAt = 0L
                showWeather()
            }
        }
    }

    private fun reloadApps() {
        bg.execute {
            val list = Apps.load(this)
            handler.post {
                apps = list
                if (!prefs.dockInit && list.isNotEmpty()) {
                    prefs.dock = Apps.defaultDock(list)
                    prefs.dockInit = true
                }
                buildDock()
                buildRecents()
                appsGrid?.let { fillGrid(it) }
            }
        }
    }

    private fun app(pkg: String): AppEntry? = apps.firstOrNull { it.pkg == pkg }

    private fun launch(a: AppEntry) {
        if (Apps.launch(this, a.pkg)) {
            prefs.pushRecent(a.pkg)
        } else {
            Toast.makeText(this, "Не удалось открыть «${a.label}»", Toast.LENGTH_SHORT).show()
        }
    }

    /** Плитка 16:9 как на Apple TV. */
    private fun appTile(a: AppEntry, radius: Number): FrameLayout = FrameLayout(this).apply {
        val iv = ImageView(context).apply {
            setImageDrawable(Art.tile(context, a))
            scaleType = ImageView.ScaleType.CENTER_CROP
        }
        addView(iv, Ui.frame(Ui.MATCH, Ui.MATCH))
        Ui.roundClip(this, radius)
    }

    private fun buildDock() {
        val hadFocus = dockRow.findFocus() != null || currentFocus == null
        dockRow.removeAllViews()
        val dock = prefs.dock.mapNotNull { app(it) }
        for (a in dock) {
            val tile = appTile(a, 22).apply {
                contentDescription = a.label
                foreground = Ui.states(Ui.rect(22, 0, Ui.white(50), 1.5), Ui.rect(22, 0, Ui.white(240), 3))
                Ui.bindFocus(this, if (prefs.zoom) 1.18f else 1.04f, if (prefs.zoom) 12 else 0) { has ->
                    if (has) { focusPkg = a.pkg; showDockLabel(this, a.label) } else hideDockLabel()
                }
                setOnClickListener { launch(a) }
                setOnLongClickListener { dockMenu(a); true }
            }
            dockRow.addView(tile, Ui.lin(Ui.px(172), Ui.px(97)))
        }
        if (ccPanel == null && appsPanel == null && hadFocus) {
            val idx = dock.indexOfFirst { it.pkg == focusPkg }.coerceAtLeast(0)
            val target = if (dockRow.childCount > 0) dockRow.getChildAt(idx) else allButton
            target.post { target.requestFocus() }
        }
    }

    private fun showDockLabel(v: View, label: String) {
        if (!prefs.showLabels) return
        dockLabel.text = label
        dockLabel.post {
            val loc = IntArray(2)
            val rootLoc = IntArray(2)
            v.getLocationInWindow(loc)
            root.getLocationInWindow(rootLoc)
            dockLabel.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
            val cx = loc[0] - rootLoc[0] + v.width * v.scaleX / 2f
            val boxLoc = IntArray(2)
            dockBox.getLocationInWindow(boxLoc)
            dockLabel.x = cx - dockLabel.measuredWidth / 2f
            dockLabel.y = (boxLoc[1] - rootLoc[1]) - dockLabel.measuredHeight - Ui.pxf(34)
            dockLabel.visibility = View.VISIBLE
        }
    }

    private fun hideDockLabel() { dockLabel.visibility = View.INVISIBLE }

    private fun buildRecents() {
        recentsRow.removeAllViews()
        val list = prefs.recents.mapNotNull { app(it) }.take(4)
        recentsBox.visibility = if (list.isEmpty() || !prefs.showRecents) View.GONE else View.VISIBLE
        for (a in list) {
            val pill = Ui.hbox(this, 12).apply {
                background = Ui.glassStates(32)
                setPadding(Ui.px(8), 0, Ui.px(24), 0)
                addView(appTile(a, 12), Ui.lin(Ui.px(86), Ui.px(48)))
                addView(Ui.text(context, a.label, 22, 600), Ui.lin(Ui.WRAP, Ui.WRAP))
                Ui.bindFocus(this, 1.06f)
                setOnClickListener { launch(a) }
            }
            recentsRow.addView(pill, Ui.lin(Ui.WRAP, Ui.px(64)))
        }
    }

    private fun dockMenu(a: AppEntry) {
        val dock = prefs.dock.toMutableList()
        val i = dock.indexOf(a.pkg)
        val items = arrayOf("Сдвинуть влево", "Сдвинуть вправо", "Убрать из Dock", "О приложении")
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, w ->
            when (w) {
                0 -> if (i > 0) { dock.removeAt(i); dock.add(i - 1, a.pkg) }
                1 -> if (i >= 0 && i < dock.size - 1) { dock.removeAt(i); dock.add(i + 1, a.pkg) }
                2 -> dock.remove(a.pkg)
                3 -> openAppInfo(a.pkg)
            }
            if (w != 3) { prefs.dock = dock; focusPkg = a.pkg; buildDock() }
        }.show()
    }

    private fun openAppInfo(pkg: String) {
        try {
            startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$pkg")))
        } catch (e: Exception) { }
    }

    // ---------------------------------------------------------------- overlays

    private fun closeOverlays() {
        ccPanel?.let { root.removeView(it) }
        appsPanel?.let { root.removeView(it) }
        ccPanel = null
        appsPanel = null
        appsGrid = null
        filter = ""
        val idx = prefs.dock.mapNotNull { app(it) }.indexOfFirst { it.pkg == focusPkg }.coerceAtLeast(0)
        val target = if (dockRow.childCount > idx) dockRow.getChildAt(idx) else allButton
        target.requestFocus()
    }

    private class Tile(val view: LinearLayout, val sub: TextView, val dot: FrameLayout)

    private fun tile(iconRes: Int, title: String, subtitle: String, active: Boolean, onClick: () -> Unit): Tile {
        val dot = FrameLayout(this)
        val sub = Ui.text(this, subtitle, 21, 500, Ui.white(215))
        val box = Ui.hbox(this, 18).apply {
            setPadding(Ui.px(22), 0, Ui.px(18), 0)
            dot.addView(Ui.icon(context, iconRes, 30), Ui.frame(Ui.px(30), Ui.px(30), Gravity.CENTER))
            addView(dot, Ui.lin(Ui.px(60), Ui.px(60)))
            val col = Ui.vbox(context, 4)
            col.addView(Ui.text(context, title, 26, 700), Ui.lin(Ui.WRAP, Ui.WRAP))
            col.addView(sub, Ui.lin(Ui.WRAP, Ui.WRAP))
            addView(col, Ui.lin(0, Ui.WRAP, 1f))
            Ui.bindFocus(this, 1.04f)
            setOnClickListener { onClick() }
        }
        val t = Tile(box, sub, dot)
        setActive(t, active)
        return t
    }

    private fun setActive(t: Tile, active: Boolean) {
        t.view.background = if (active)
            Ui.states(Ui.rect(30, Color.rgb(29, 111, 242)), Ui.rect(30, Color.rgb(64, 140, 255), Ui.white(240), 3))
        else Ui.glassStates(30)
        t.dot.background = Ui.rect(30, if (active) Ui.white(255) else Ui.white(56))
        (t.dot.getChildAt(0) as ImageView).setColorFilter(if (active) Color.rgb(29, 111, 242) else Color.WHITE)
    }

    private fun row(vararg tiles: View): LinearLayout = Ui.hbox(this, 18).apply {
        for (t in tiles) addView(t, Ui.lin(0, Ui.px(112), 1f))
    }

    private fun closeButton(size: Int): View = FrameLayout(this).apply {
        background = Ui.states(Ui.rect(size / 2, Ui.white(40)), Ui.rect(size / 2, Ui.white(120), Ui.white(230), 2.5))
        addView(Ui.icon(context, R.drawable.ic_close, size / 2), Ui.frame(Ui.px(size / 2), Ui.px(size / 2), Gravity.CENTER))
        contentDescription = "Закрыть"
        Ui.bindFocus(this, 1.1f)
        setOnClickListener { closeOverlays() }
    }

    private fun networkText(): String {
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return "Нет сети"
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Кабель подключён"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Подключено"
            else -> "Подключено"
        }
    }

    private fun memText(): String {
        val (free, total) = Apps.memory(this)
        return "Свободно ${free / 1_048_576} из ${total / 1_048_576} МБ"
    }

    private fun openCC() {
        closeOverlays()
        hideDockLabel()
        val panel = Ui.vbox(this, 18).apply {
            background = Ui.panel(44)
            pad(32, 32)
            isClickable = true
        }
        val head = Ui.hbox(this)
        head.addView(Ui.text(this, "Пункт управления", 34, 700), Ui.lin(0, Ui.WRAP, 1f))
        head.addView(closeButton(60), Ui.lin(Ui.px(60), Ui.px(60)))
        panel.addView(head, Ui.lin(Ui.MATCH, Ui.WRAP))

        val online = networkText() != "Нет сети"
        val wifi = tile(R.drawable.ic_wifi, "Сеть", networkText(), online) {
            try { startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)) } catch (e: Exception) { }
        }
        val inputs = tile(R.drawable.ic_input, "Источники", "HDMI и антенна", false) { showInputs() }
        panel.addView(row(wifi.view, inputs.view), Ui.lin(Ui.MATCH, Ui.WRAP))

        // Звук
        val am = getSystemService(AudioManager::class.java)
        val vol = Ui.vbox(this, 14).apply {
            background = Ui.glass(30)
            pad(26, 22)
        }
        vol.addView(Ui.text(this, "Звук", 24, 700), Ui.lin(Ui.WRAP, Ui.WRAP))
        val seek = SeekBar(this).apply {
            max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
            progress = am.getStreamVolume(AudioManager.STREAM_MUSIC)
            progressTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            thumbTintList = android.content.res.ColorStateList.valueOf(Color.WHITE)
            progressBackgroundTintList = android.content.res.ColorStateList.valueOf(Ui.white(90))
            contentDescription = "Громкость"
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                    if (fromUser) am.setStreamVolume(AudioManager.STREAM_MUSIC, p, AudioManager.FLAG_SHOW_UI)
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
            setOnFocusChangeListener { _, has -> vol.background = if (has) Ui.rect(30, Ui.white(80), Ui.white(220), 2.5) else Ui.glass(30) }
        }
        vol.addView(seek, Ui.lin(Ui.MATCH, Ui.px(48)))
        panel.addView(vol, Ui.lin(Ui.MATCH, Ui.WRAP))

        lateinit var boost: Tile
        boost = tile(R.drawable.ic_bolt, "Ускорить", memText(), false) {
            boost.sub.text = "Выгружаю…"
            val list = apps
            bg.execute {
                val freed = Apps.boost(this, list)
                handler.post {
                    boost.sub.text = "Освобождено ${freed / 1_048_576} МБ"
                    setActive(boost, true)
                }
            }
        }
        lateinit var night: Tile
        night = tile(R.drawable.ic_moon, "Ночной режим", if (prefs.night) "Вкл." else "Выкл.", prefs.night) {
            prefs.night = !prefs.night
            night.sub.text = if (prefs.night) "Вкл." else "Выкл."
            setActive(night, prefs.night)
            nightView.visibility = if (prefs.isNightNow()) View.VISIBLE else View.GONE
        }
        panel.addView(row(boost.view, night.view), Ui.lin(Ui.MATCH, Ui.WRAP))

        val settings = tile(R.drawable.ic_gear, "Настройки", "Оформление, Dock", false) {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        val tv = tile(R.drawable.ic_tv, "Настройки ТВ", "Системные", false) {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e: Exception) { }
        }
        panel.addView(row(settings.view, tv.view), Ui.lin(Ui.MATCH, Ui.WRAP))

        root.addView(panel, Ui.frame(Ui.px(660), Ui.WRAP, Gravity.TOP or Gravity.END).m(t = 64, r = 72))
        ccPanel = panel
        wifi.view.post { wifi.view.requestFocus() }
    }

    private fun showInputs() {
        val tim = getSystemService(TvInputManager::class.java)
        val inputs = try { tim?.tvInputList?.filter { it.isPassthroughInput } ?: emptyList() } catch (e: Exception) { emptyList() }
        if (inputs.isEmpty()) {
            Toast.makeText(this, "Входы не найдены", Toast.LENGTH_SHORT).show()
            return
        }
        val names = inputs.map { (it.loadLabel(this) ?: it.id).toString() }.toTypedArray()
        AlertDialog.Builder(this).setTitle("Источник").setItems(names) { _, w ->
            try {
                startActivity(
                    Intent(Intent.ACTION_VIEW, TvContract.buildChannelUriForPassthroughInput(inputs[w].id))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                )
            } catch (e: Exception) {
                Toast.makeText(this, "Не удалось переключить вход", Toast.LENGTH_SHORT).show()
            }
        }.show()
    }

    // ---------------------------------------------------------------- all apps

    private lateinit var hiddenBtnText: TextView

    private fun openApps() {
        closeOverlays()
        hideDockLabel()
        val dim = FrameLayout(this).apply {
            setBackgroundColor(Color.argb(110, 5, 6, 20))
            isClickable = true
        }
        val sheet = Ui.vbox(this, 36).apply {
            background = Ui.panel(56)
            setPadding(Ui.px(56), Ui.px(48), Ui.px(56), Ui.px(40))
        }
        val head = Ui.hbox(this, 24)
        head.addView(Ui.text(this, "Все приложения", 44, 700), Ui.lin(0, Ui.WRAP, 1f))

        val search = EditText(this).apply {
            hint = "Поиск"
            setHintTextColor(Ui.white(160))
            setTextColor(Color.WHITE)
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, Ui.pxf(26))
            typeface = Ui.font(500)
            isSingleLine = true
            imeOptions = EditorInfo.IME_ACTION_DONE
            background = Ui.glassStates(34)
            setPadding(Ui.px(28), 0, Ui.px(28), 0)
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    filter = s?.toString()?.trim()?.lowercase() ?: ""
                    appsGrid?.let { fillGrid(it) }
                }
            })
        }
        head.addView(search, Ui.lin(Ui.px(520), Ui.px(68)))

        val hiddenBtn = Ui.hbox(this, 12).apply {
            background = Ui.glassStates(34)
            setPadding(Ui.px(24), 0, Ui.px(26), 0)
            addView(Ui.icon(context, R.drawable.ic_eye, 28), Ui.lin(Ui.px(28), Ui.px(28)))
            hiddenBtnText = Ui.text(context, hiddenLabel(), 24, 600)
            addView(hiddenBtnText, Ui.lin(Ui.WRAP, Ui.WRAP))
            Ui.bindFocus(this, 1.05f)
            setOnClickListener {
                showHidden = !showHidden
                hiddenBtnText.text = hiddenLabel()
                appsGrid?.let { fillGrid(it) }
            }
        }
        head.addView(hiddenBtn, Ui.lin(Ui.WRAP, Ui.px(68)))
        head.addView(closeButton(68), Ui.lin(Ui.px(68), Ui.px(68)))
        sheet.addView(head, Ui.lin(Ui.MATCH, Ui.WRAP))

        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            clipToPadding = false
            setPadding(0, Ui.px(16), 0, Ui.px(16))
        }
        val grid = Ui.vbox(this, 30).apply { clipChildren = false }
        scroll.addView(grid, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        sheet.addView(scroll, Ui.lin(Ui.MATCH, 0, 1f))
        appsGrid = grid
        fillGrid(grid)

        dim.addView(sheet, Ui.frame(Ui.px(1600), Ui.px(940), Gravity.CENTER))
        root.addView(dim, Ui.frame(Ui.MATCH, Ui.MATCH))
        appsPanel = dim
        grid.post { (grid.getChildAt(0) as? ViewGroup)?.getChildAt(0)?.requestFocus() }
    }

    private fun hiddenLabel(): String =
        if (showHidden) "Убрать скрытые" else "Скрытые (${prefs.hidden.count { h -> apps.any { it.pkg == h } }})"

    private fun fillGrid(grid: LinearLayout) {
        grid.removeAllViews()
        val hidden = prefs.hidden
        val list = apps.filter {
            (showHidden || it.pkg !in hidden) && (filter.isEmpty() || it.label.lowercase().contains(filter))
        }
        if (list.isEmpty()) {
            grid.addView(Ui.text(this, "Ничего не найдено", 28, 500, Ui.white(200)), Ui.lin(Ui.WRAP, Ui.WRAP))
            return
        }
        for (chunk in list.chunked(6)) {
            val row = Ui.hbox(this).apply { clipChildren = false }
            for (a in chunk) {
                val cell = Ui.vbox(this, 14).apply {
                    gravity = Gravity.CENTER_HORIZONTAL
                    clipChildren = false
                    val t = appTile(a, 24).apply {
                        foreground = Ui.states(Ui.rect(24, 0, Ui.white(50), 1.5), Ui.rect(24, 0, Ui.white(240), 3.5f))
                        isDuplicateParentStateEnabled = true
                    }
                    addView(t, Ui.lin(Ui.px(214), Ui.px(120)))
                    addView(Ui.text(context, a.label, 22, 500, Ui.white(240)).apply { gravity = Gravity.CENTER },
                        Ui.lin(Ui.px(220), Ui.WRAP))
                    alpha = if (a.pkg in hidden) 0.5f else 1f
                    Ui.bindFocus(this, 1.08f)
                    setOnClickListener { launch(a) }
                    setOnLongClickListener { appMenu(a); true }
                }
                row.addView(cell, Ui.lin(0, Ui.WRAP, 1f))
            }
            for (i in chunk.size until 6) row.addView(View(this), Ui.lin(0, 1, 1f))
            grid.addView(row, Ui.lin(Ui.MATCH, Ui.WRAP))
        }
    }

    private fun appMenu(a: AppEntry) {
        val inDock = a.pkg in prefs.dock
        val isHidden = a.pkg in prefs.hidden
        val items = arrayOf(
            if (inDock) "Убрать из Dock" else "Добавить в Dock",
            if (isHidden) "Показывать в списке" else "Скрыть из списка",
            "О приложении"
        )
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, w ->
            when (w) {
                0 -> { prefs.dock = if (inDock) prefs.dock - a.pkg else prefs.dock + a.pkg; buildDock() }
                1 -> {
                    prefs.hidden = if (isHidden) prefs.hidden - a.pkg else prefs.hidden + a.pkg
                    hiddenBtnText.text = hiddenLabel()
                    appsGrid?.let { fillGrid(it) }
                }
                2 -> openAppInfo(a.pkg)
            }
        }.show()
    }

    // ---------------------------------------------------------------- screensaver

    private fun showSaver() {
        if (saverView != null || !hasWindowFocus()) return
        val v = FrameLayout(this).apply { alpha = 0f }
        val iv = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        loadWallpaper(iv, this, prefs.wallpaper)
        v.addView(iv, Ui.frame(Ui.MATCH, Ui.MATCH))
        v.addView(View(this).apply {
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(Ui.black(130), Ui.black(30), 0))
        }, Ui.frame(Ui.MATCH, Ui.MATCH))
        val col = Ui.vbox(this, 6)
        col.addView(Ui.text(this, dateText(), 34, 600, Ui.white(230)), Ui.lin(Ui.WRAP, Ui.WRAP))
        val clock = TextClock(this).apply {
            includeFontPadding = false
            val fmt = if (prefs.h24) "HH:mm" else "h:mm"
            format24Hour = fmt; format12Hour = fmt
            typeface = Ui.font(200)
            setTextColor(Color.WHITE)
            setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, Ui.pxf(300))
            letterSpacing = -0.03f
        }
        col.addView(clock, Ui.lin(Ui.WRAP, Ui.WRAP))
        col.addView(Ui.text(this, weatherView.text, 32, 500, Ui.white(230)), Ui.lin(Ui.WRAP, Ui.WRAP))
        v.addView(col, Ui.frame(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.START).m(l = 120, b = 110))
        v.addView(Ui.text(this, "Нажмите любую кнопку на пульте", 24, 500, Ui.white(230)).apply {
            background = Ui.glass(28)
            pad(26, 14)
        }, Ui.frame(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.END).m(r = 96, b = 120))
        root.addView(v, Ui.frame(Ui.MATCH, Ui.MATCH))
        v.animate().alpha(1f).setDuration(600).start()
        saverView = v
    }

    private fun hideSaver() {
        saverView?.let { root.removeView(it) }
        saverView = null
        resetIdle()
    }
}
