package com.vadim.tvlauncher

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.concurrent.Executors

class SettingsActivity : Activity() {
    private lateinit var prefs: Prefs
    private lateinit var wall: ImageView
    private lateinit var content: LinearLayout
    private lateinit var scroll: ScrollView
    private lateinit var sideBox: LinearLayout
    private val handler = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private var section = "look"
    private var apps: List<AppEntry> = emptyList()

    private val sections = listOf(
        "look" to "Оформление",
        "main" to "Основные",
        "dock" to "Приложения и Dock",
        "sys" to "Система"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.init(this)
        prefs = Prefs(this)

        val root = FrameLayout(this)
        wall = ImageView(this).apply { scaleType = ImageView.ScaleType.CENTER_CROP }
        root.addView(wall, Ui.frame(Ui.MATCH, Ui.MATCH))
        root.addView(View(this).apply { setBackgroundColor(Ui.black(60)) }, Ui.frame(Ui.MATCH, Ui.MATCH))

        val window = Ui.hbox(this, 40).apply {
            gravity = Gravity.TOP
            background = Ui.panel(56)
            pad(40, 40)
        }

        sideBox = Ui.vbox(this, 12)
        val back = Ui.hbox(this, 10).apply {
            addView(Ui.icon(context, R.drawable.ic_back, 26, Ui.white(220)), Ui.lin(Ui.px(26), Ui.px(26)))
            addView(Ui.text(context, "На главный экран", 24, 600, Ui.white(220)), Ui.lin(Ui.WRAP, Ui.WRAP))
            background = Ui.states(Ui.rect(20, 0), Ui.rect(20, Ui.white(60)))
            pad(12, 10)
            Ui.bindFocus(this, 1.03f)
            setOnClickListener { finish() }
        }
        sideBox.addView(back, Ui.lin(Ui.WRAP, Ui.WRAP))
        sideBox.addView(Ui.text(this, "Настройки", 52, 700), Ui.lin(Ui.WRAP, Ui.WRAP).m(l = 8, t = 6, b = 18))
        window.addView(sideBox, Ui.lin(Ui.px(400), Ui.MATCH))

        scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            background = Ui.rect(40, Ui.white(20), Ui.white(40))
            clipToPadding = false
        }
        content = Ui.vbox(this, 18).apply { pad(44, 40) }
        scroll.addView(content, ViewGroup.LayoutParams(Ui.MATCH, Ui.WRAP))
        window.addView(scroll, Ui.lin(0, Ui.MATCH, 1f))

        root.addView(window, Ui.frame(Ui.px(1640), Ui.px(900), Gravity.CENTER))
        setContentView(root)

        buildSidebar()
        bg.execute {
            val list = Apps.load(this)
            handler.post { apps = list; if (section == "dock") show(section) }
        }
    }

    override fun onResume() {
        super.onResume()
        loadWallpaper(wall, this, prefs.wallpaper)
        show(section)
    }

    private val sideButtons = mutableMapOf<String, TextView>()

    private fun buildSidebar() {
        for ((key, label) in sections) {
            val b = Ui.text(this, label, 26, 600).apply {
                gravity = Gravity.CENTER_VERTICAL
                setPadding(Ui.px(24), 0, Ui.px(24), 0)
                Ui.bindFocus(this, 1.03f)
                setOnClickListener { section = key; show(key) }
                setOnFocusChangeListener { v, has ->
                    v.animate().scaleX(if (has) 1.03f else 1f).scaleY(if (has) 1.03f else 1f).setDuration(150).start()
                    if (has && section != key) { section = key; show(key, keepFocus = true) }
                }
            }
            sideButtons[key] = b
            sideBox.addView(b, Ui.lin(Ui.MATCH, Ui.px(72)))
        }
        sideButtons[section]?.post { sideButtons[section]?.requestFocus() }
    }

    private fun refreshSidebar() {
        for ((key, b) in sideButtons) {
            val on = key == section
            b.background = Ui.states(
                Ui.rect(24, if (on) Ui.white(70) else Ui.white(20), Ui.white(if (on) 140 else 40)),
                Ui.rect(24, Ui.white(110), Ui.white(230), 2.5)
            )
        }
    }

    // ---------------------------------------------------------------- building blocks

    private fun show(key: String, keepFocus: Boolean = false, focusTag: String? = null) {
        refreshSidebar()
        content.removeAllViews()
        when (key) {
            "look" -> look()
            "main" -> main()
            "dock" -> dock()
            "sys" -> sys()
        }
        if (focusTag != null) {
            content.post { content.findViewWithTag<View>(focusTag)?.requestFocus() }
        } else if (!keepFocus) {
            scroll.scrollTo(0, 0)
        }
    }

    private fun rebuild(tag: String) = show(section, focusTag = tag)

    private fun title(s: String) = content.addView(Ui.text(this, s, 42, 700), Ui.lin(Ui.WRAP, Ui.WRAP).m(b = 6))

    private fun h3(s: String) =
        content.addView(Ui.text(this, s, 24, 700, Ui.white(195)), Ui.lin(Ui.WRAP, Ui.WRAP).m(l = 6, t = 14))

    private fun note(s: String) =
        content.addView(Ui.text(this, s, 22, 500, Ui.white(200), single = false), Ui.lin(Ui.MATCH, Ui.WRAP).m(l = 6))

    private fun rowView(label: String, value: String, valueColor: Int, tag: String, onClick: (() -> Unit)?): LinearLayout =
        Ui.hbox(this, 20).apply {
            this.tag = tag
            background = if (onClick != null) Ui.glassStates(26, Ui.white(30)) else Ui.glass(26, Ui.white(30), Ui.white(45))
            setPadding(Ui.px(28), 0, Ui.px(28), 0)
            addView(Ui.text(context, label, 26, 600), Ui.lin(0, Ui.WRAP, 1f))
            addView(Ui.text(context, value, 24, 600, valueColor), Ui.lin(Ui.WRAP, Ui.WRAP))
            if (onClick != null) {
                Ui.bindFocus(this, 1.02f)
                setOnClickListener { onClick() }
            }
        }

    private fun row(label: String, value: String, tag: String, onClick: (() -> Unit)?) =
        content.addView(rowView(label, value, Ui.white(210), tag, onClick), Ui.lin(Ui.MATCH, Ui.px(84)))

    private fun toggle(label: String, tag: String, get: () -> Boolean, set: (Boolean) -> Unit) {
        val on = get()
        val v = rowView(label, if (on) "Вкл." else "Выкл.", if (on) Color.rgb(74, 222, 128) else Ui.white(170), tag) {
            set(!get()); rebuild(tag)
        }
        content.addView(v, Ui.lin(Ui.MATCH, Ui.px(84)))
    }

    private fun chip(label: String, selected: Boolean, tag: String, onClick: () -> Unit): TextView =
        Ui.text(this, label, 22, 600, if (selected) Color.rgb(17, 24, 39) else Color.WHITE).apply {
            this.tag = tag
            gravity = Gravity.CENTER
            setPadding(Ui.px(24), 0, Ui.px(24), 0)
            background = if (selected)
                Ui.states(Ui.rect(30, Color.WHITE), Ui.rect(30, Color.WHITE, Color.rgb(96, 165, 250), 4))
            else Ui.glassStates(30, Ui.white(36))
            Ui.bindFocus(this, 1.06f)
            setOnClickListener { onClick() }
        }

    private fun chipRows(items: List<View>, perRow: Int) {
        for (chunk in items.chunked(perRow)) {
            val r = Ui.hbox(this, 14)
            for (v in chunk) r.addView(v, Ui.lin(Ui.WRAP, Ui.px(60)))
            content.addView(r, Ui.lin(Ui.MATCH, Ui.WRAP))
        }
    }

    private fun thumb(resId: Int): android.graphics.Bitmap? =
        BitmapFactory.decodeResource(resources, resId, BitmapFactory.Options().apply { inSampleSize = 8 })

    // ---------------------------------------------------------------- sections

    private fun look() {
        title("Оформление")
        h3("Часы")
        val clocks = listOf("glass" to "Стекло", "glow" to "Свечение", "thin" to "Тонкие")
        val crow = Ui.hbox(this, 18)
        for ((k, label) in clocks) {
            val sel = prefs.clockStyle == k
            val card = Ui.vbox(this, 8).apply {
                tag = "clock_$k"
                gravity = Gravity.CENTER
                background = Ui.states(
                    Ui.rect(30, Ui.white(if (sel) 60 else 24), if (sel) Color.WHITE else Ui.white(50), if (sel) 4 else 1.5),
                    Ui.rect(30, Ui.white(80), Color.WHITE, 4)
                )
                val tv = TextView(context).apply { text = "17:20"; includeFontPadding = false }
                val tmp = Prefs(context)
                styleClock(tv, tmp, if (k == "thin") 90 else 84)
                when (k) {
                    "glow" -> { tv.typeface = Ui.font(500); tv.setTextColor(Color.WHITE); tv.setShadowLayer(Ui.pxf(18), 0f, 0f, Walls.glow(prefs.wallpaper)) }
                    "thin" -> { tv.typeface = Ui.font(200); tv.setTextColor(Color.WHITE); tv.setShadowLayer(0f, 0f, 0f, 0) }
                    else -> { tv.typeface = Ui.font(600); tv.setTextColor(Ui.white(228)); tv.setShadowLayer(Ui.pxf(12), 0f, Ui.pxf(4), Ui.black(80)) }
                }
                addView(tv, Ui.lin(Ui.WRAP, Ui.WRAP))
                addView(Ui.text(context, label, 22, 600), Ui.lin(Ui.WRAP, Ui.WRAP))
                Ui.bindFocus(this, 1.04f)
                setOnClickListener { prefs.clockStyle = k; rebuild("clock_$k") }
            }
            crow.addView(card, Ui.lin(0, Ui.px(200), 1f))
        }
        content.addView(crow, Ui.lin(Ui.MATCH, Ui.WRAP))

        h3("Обои")
        val wrow = Ui.hbox(this, 18)
        for (k in Walls.keys) {
            val sel = prefs.wallpaper == k
            val f = FrameLayout(this).apply {
                tag = "wall_$k"
                addView(ImageView(context).apply {
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    setImageBitmap(thumb(Walls.res(k)))
                }, Ui.frame(Ui.MATCH, Ui.MATCH))
                addView(Ui.text(context, Walls.names[k] ?: k, 20, 600).apply {
                    background = Ui.rect(14, Ui.black(80)); pad(14, 6)
                }, Ui.frame(Ui.WRAP, Ui.WRAP, Gravity.BOTTOM or Gravity.START).m(l = 12, b = 12))
                foreground = Ui.states(
                    if (sel) Ui.rect(26, 0, Color.WHITE, 4) else Ui.rect(26, 0, Ui.white(60), 1.5),
                    Ui.rect(26, 0, Color.WHITE, 5)
                )
                Ui.roundClip(this, 26)
                Ui.bindFocus(this, 1.05f)
                setOnClickListener { prefs.wallpaper = k; loadWallpaper(wall, context, k); rebuild("wall_$k") }
            }
            wrow.addView(f, Ui.lin(0, Ui.px(140), 1f))
        }
        val custom = Ui.vbox(this, 6).apply {
            tag = "wall_custom"
            gravity = Gravity.CENTER
            val sel = prefs.wallpaper == "custom"
            background = Ui.states(
                Ui.rect(26, Ui.white(if (sel) 60 else 20), if (sel) Color.WHITE else Ui.white(140), if (sel) 4 else 2),
                Ui.rect(26, Ui.white(80), Color.WHITE, 4)
            )
            addView(Ui.text(context, "+ Своя", 24, 700), Ui.lin(Ui.WRAP, Ui.WRAP))
            addView(Ui.text(context, "из «Загрузок»", 18, 500, Ui.white(200)), Ui.lin(Ui.WRAP, Ui.WRAP))
            Ui.bindFocus(this, 1.05f)
            setOnClickListener { pickCustomWallpaper() }
        }
        wrow.addView(custom, Ui.lin(0, Ui.px(140), 1f))
        content.addView(wrow, Ui.lin(Ui.MATCH, Ui.WRAP))
        note("Своя картинка: отправьте фото на телевизор через Send Files to TV в папку Download и назовите его wallpaper.jpg.")

        h3("Главный экран")
        toggle("Ряд «Недавние»", "recents", { prefs.showRecents }, { prefs.showRecents = it })
    }

    private fun main() {
        title("Основные")
        row("Город для погоды", prefs.city, "city") { askCity() }
        toggle("24-часовой формат", "h24", { prefs.h24 }, { prefs.h24 = it })
        val saverText = if (prefs.saverMin == 0) "Выкл." else "через ${prefs.saverMin} мин"
        row("Заставка без действий", saverText, "saver") {
            val opts = listOf(0, 5, 10, 15, 30)
            val i = opts.indexOf(prefs.saverMin)
            prefs.saverMin = opts[(i + 1) % opts.size]
            rebuild("saver")
        }
        toggle("Ночной режим по расписанию (23:00–7:00)", "nightAuto", { prefs.nightAuto }, { prefs.nightAuto = it })
        note("Ночной режим затемняет главный экран лаунчера тёплым оттенком. Включить вручную можно в «Пункте управления».")
    }

    private fun dock() {
        title("Приложения и Dock")
        toggle("Подписи над выбранной иконкой", "labels", { prefs.showLabels }, { prefs.showLabels = it })
        toggle("Увеличение иконок", "zoom", { prefs.zoom }, { prefs.zoom = it })
        row("Собрать Dock заново", "по умолчанию", "redock") {
            if (apps.isNotEmpty()) {
                prefs.dock = Apps.defaultDock(apps)
                Toast.makeText(this, "Dock обновлён", Toast.LENGTH_SHORT).show()
            }
        }
        note("Чтобы добавить приложение в Dock, переставить или убрать его — удерживайте ОК на иконке.")
        h3("Скрытые приложения")
        note("Отмеченные не показываются во «Всех приложениях». Нажмите, чтобы скрыть или вернуть.")
        if (apps.isEmpty()) {
            note("Загружаю список…")
            return
        }
        val hidden = prefs.hidden
        val chips = apps.map { a ->
            val h = a.pkg in hidden
            chip((if (h) "✓ " else "") + a.label, h, "hide_${a.pkg}") {
                prefs.hidden = if (h) prefs.hidden - a.pkg else prefs.hidden + a.pkg
                rebuild("hide_${a.pkg}")
            }
        }
        chipRows(chips, 4)
    }

    private fun sys() {
        title("Система")
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (e: Exception) { "" }
        row("Версия лаунчера", ver ?: "", "ver", null)
        row("Телевизор", "${Build.MODEL} · Android ${Build.VERSION.RELEASE}", "model", null)
        toggle("Кнопка «Домой» открывает этот лаунчер", "home", { prefs.homeOverride }, { prefs.homeOverride = it })
        row("Служба кнопки «Домой»", "Специальные возможности", "a11y") {
            try { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) } catch (e: Exception) { }
        }
        note("Чтобы кнопка «Домой» вела сюда, включите в «Специальных возможностях» службу «Лаунчер: кнопка «Домой»».")
        row("Открыть настройки телевизора", "", "tvset") {
            try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e: Exception) { }
        }
        content.addView(rowView("Вернуть стандартный экран Google TV", "", Color.rgb(252, 165, 165), "restore") {
            AlertDialog.Builder(this)
                .setTitle("Вернуть стандартный экран")
                .setMessage("Выключите переключатель «Кнопка «Домой» открывает этот лаунчер» выше — и «Домой» снова будет вести на экран Google TV. Сам лаунчер можно удалить в Настройках ТВ → Приложения.")
                .setPositiveButton("Выключить сейчас") { _, _ -> prefs.homeOverride = false; rebuild("home") }
                .setNegativeButton("Отмена", null)
                .show()
        }, Ui.lin(Ui.MATCH, Ui.px(84)))
    }

    // ---------------------------------------------------------------- actions

    private fun askCity() {
        val input = EditText(this).apply {
            setText(prefs.city)
            isSingleLine = true
            setSelection(text.length)
        }
        AlertDialog.Builder(this)
            .setTitle("Город для погоды")
            .setView(FrameLayout(this).apply {
                pad(40, 10)
                addView(input, Ui.frame(Ui.MATCH, Ui.WRAP))
            })
            .setPositiveButton("Сохранить") { _, _ ->
                val name = input.text.toString().trim()
                if (name.isEmpty()) return@setPositiveButton
                bg.execute {
                    val r = Weather.geocode(name)
                    handler.post {
                        if (r == null) {
                            Toast.makeText(this, "Город не найден", Toast.LENGTH_SHORT).show()
                        } else {
                            prefs.city = r.first; prefs.lat = r.second; prefs.lon = r.third
                            prefs.weatherAt = 0L; prefs.weather = ""
                            rebuild("city")
                        }
                    }
                }
            }
            .setNegativeButton("Отмена", null)
            .show()
    }

    private val permCode = 41

    private fun pickCustomWallpaper() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(arrayOf(perm), permCode)
            return
        }
        copyCustomWallpaper()
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == permCode && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) copyCustomWallpaper()
        else if (requestCode == permCode) Toast.makeText(this, "Нужен доступ к файлам, чтобы взять картинку", Toast.LENGTH_LONG).show()
    }

    private fun copyCustomWallpaper() {
        @Suppress("DEPRECATION")
        val dl = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        val src = listOf("wallpaper.jpg", "wallpaper.jpeg", "wallpaper.png", "wallpaper.webp")
            .map { File(dl, it) }.firstOrNull { it.exists() }
            ?: dl.listFiles()?.filter { it.isFile && it.name.lowercase().matches(Regex(".*\\.(jpg|jpeg|png|webp)")) }
                ?.maxByOrNull { it.lastModified() }
        if (src == null) {
            Toast.makeText(this, "В папке Download нет картинок. Отправьте фото через Send Files to TV.", Toast.LENGTH_LONG).show()
            return
        }
        try {
            src.inputStream().use { input -> File(filesDir, "custom_wall").outputStream().use { input.copyTo(it) } }
            prefs.wallpaper = "custom"
            loadWallpaper(wall, this, "custom")
            Toast.makeText(this, "Обои: ${src.name}", Toast.LENGTH_SHORT).show()
            rebuild("wall_custom")
        } catch (e: Exception) {
            Toast.makeText(this, "Не удалось прочитать ${src.name}", Toast.LENGTH_LONG).show()
        }
    }
}
