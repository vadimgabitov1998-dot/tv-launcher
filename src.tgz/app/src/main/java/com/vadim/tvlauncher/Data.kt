package com.vadim.tvlauncher

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Calendar
import kotlin.math.roundToInt

class Prefs(ctx: Context) {
    private val p: SharedPreferences = ctx.getSharedPreferences("launcher", Context.MODE_PRIVATE)

    private fun str(k: String, d: String) = p.getString(k, d) ?: d
    private fun put(k: String, v: String) = p.edit().putString(k, v).apply()
    private fun bool(k: String, d: Boolean) = p.getBoolean(k, d)
    private fun putB(k: String, v: Boolean) = p.edit().putBoolean(k, v).apply()
    private fun list(k: String): List<String> = str(k, "").split("|").filter { it.isNotEmpty() }
    private fun putList(k: String, v: List<String>) = put(k, v.joinToString("|"))

    var wallpaper: String get() = str("wallpaper", "volny"); set(v) = put("wallpaper", v)
    var clockStyle: String get() = str("clock", "glass"); set(v) = put("clock", v)
    var dock: List<String> get() = list("dock"); set(v) = putList("dock", v)
    var dockInit: Boolean get() = bool("dockInit", false); set(v) = putB("dockInit", v)
    var hidden: Set<String> get() = list("hidden").toSet(); set(v) = putList("hidden", v.toList())
    var recents: List<String> get() = list("recents"); set(v) = putList("recents", v)
    var h24: Boolean get() = bool("h24", true); set(v) = putB("h24", v)
    var showLabels: Boolean get() = bool("labels", true); set(v) = putB("labels", v)
    var zoom: Boolean get() = bool("zoom", true); set(v) = putB("zoom", v)
    var showRecents: Boolean get() = bool("recentsOn", true); set(v) = putB("recentsOn", v)
    var saverMin: Int get() = p.getInt("saver", 5); set(v) = p.edit().putInt("saver", v).apply()
    var night: Boolean get() = bool("night", false); set(v) = putB("night", v)
    var nightAuto: Boolean get() = bool("nightAuto", false); set(v) = putB("nightAuto", v)
    var homeOverride: Boolean get() = bool("homeOverride", true); set(v) = putB("homeOverride", v)
    var city: String get() = str("city", "Челябинск"); set(v) = put("city", v)
    var lat: Float get() = p.getFloat("lat", 55.16f); set(v) = p.edit().putFloat("lat", v).apply()
    var lon: Float get() = p.getFloat("lon", 61.40f); set(v) = p.edit().putFloat("lon", v).apply()
    var weather: String get() = str("weather", ""); set(v) = put("weather", v)
    var weatherAt: Long get() = p.getLong("weatherAt", 0L); set(v) = p.edit().putLong("weatherAt", v).apply()

    fun isNightNow(): Boolean {
        if (night) return true
        if (!nightAuto) return false
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        return h >= 23 || h < 7
    }

    fun pushRecent(pkg: String) {
        recents = (listOf(pkg) + recents.filter { it != pkg }).take(8)
    }
}

data class AppEntry(val label: String, val pkg: String, val icon: Drawable, val banner: Drawable?)

object Apps {
    fun load(ctx: Context): List<AppEntry> {
        val pm = ctx.packageManager
        val out = LinkedHashMap<String, AppEntry>()
        for (cat in listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)) {
            val intent = Intent(Intent.ACTION_MAIN).addCategory(cat)
            val found = try { pm.queryIntentActivities(intent, 0) } catch (e: Exception) { emptyList() }
            for (ri in found) {
                val pkg = ri.activityInfo.packageName
                if (pkg == ctx.packageName || out.containsKey(pkg)) continue
                val label = try { ri.loadLabel(pm).toString() } catch (e: Exception) { pkg }
                val icon = try { ri.loadIcon(pm) } catch (e: Exception) { pm.defaultActivityIcon }
                val banner = try {
                    ri.activityInfo.loadBanner(pm) ?: pm.getApplicationBanner(pkg)
                } catch (e: Exception) { null }
                out[pkg] = AppEntry(label, pkg, icon, banner)
            }
        }
        return out.values.sortedBy { it.label.lowercase() }
    }

    fun launch(ctx: Context, pkg: String): Boolean {
        val pm = ctx.packageManager
        val intent = pm.getLeanbackLaunchIntentForPackage(pkg) ?: pm.getLaunchIntentForPackage(pkg) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        return try { ctx.startActivity(intent); true } catch (e: Exception) { false }
    }

    private val defaultKeys = listOf(
        "youtube", "кинопоиск", "kinopoisk", "иви", "ivi", "okko", "zona", "vpn",
        "tv bro", "браузер", "browser", "chrome"
    )

    fun defaultDock(apps: List<AppEntry>): List<String> {
        val out = mutableListOf<String>()
        for (k in defaultKeys) {
            val a = apps.firstOrNull { it.label.lowercase().contains(k) && it.pkg !in out }
            if (a != null) out += a.pkg
        }
        if (out.isEmpty()) out += apps.take(6).map { it.pkg }
        return out.take(8)
    }

    fun memory(ctx: Context): Pair<Long, Long> {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val mi = ActivityManager.MemoryInfo()
        am.getMemoryInfo(mi)
        return mi.availMem to mi.totalMem
    }

    /** Выгружает фоновые процессы всех приложений. Возвращает освобождённые байты. */
    fun boost(ctx: Context, apps: List<AppEntry>): Long {
        val am = ctx.getSystemService(ActivityManager::class.java)
        val before = memory(ctx).first
        for (a in apps) {
            try { am.killBackgroundProcesses(a.pkg) } catch (e: Exception) { }
        }
        Thread.sleep(800)
        return maxOf(0L, memory(ctx).first - before)
    }
}

object Weather {
    private fun get(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        return try { c.inputStream.bufferedReader().readText() } finally { c.disconnect() }
    }

    private fun describe(code: Int): String = when (code) {
        0 -> "Ясно"
        1, 2 -> "Малооблачно"
        3 -> "Облачно"
        45, 48 -> "Туман"
        in 51..57 -> "Морось"
        in 61..67 -> "Дождь"
        in 71..77 -> "Снег"
        in 80..82 -> "Ливень"
        85, 86 -> "Снегопад"
        in 95..99 -> "Гроза"
        else -> ""
    }

    /** Например: «−6° Облачно». null — если нет сети. */
    fun fetch(lat: Float, lon: Float): String? = try {
        val j = JSONObject(get("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto"))
        val cur = j.getJSONObject("current")
        val t = cur.getDouble("temperature_2m").roundToInt()
        val sign = if (t < 0) "−" else if (t > 0) "+" else ""
        "$sign${kotlin.math.abs(t)}° ${describe(cur.getInt("weather_code"))}".trim()
    } catch (e: Exception) { null }

    /** Поиск города: имя, широта, долгота. */
    fun geocode(name: String): Triple<String, Float, Float>? = try {
        val q = URLEncoder.encode(name, "UTF-8")
        val j = JSONObject(get("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=ru"))
        val r = j.getJSONArray("results").getJSONObject(0)
        Triple(r.getString("name"), r.getDouble("latitude").toFloat(), r.getDouble("longitude").toFloat())
    } catch (e: Exception) { null }
}

object Walls {
    val keys = listOf("volny", "zakat", "noch", "myata")
    val names = mapOf("volny" to "Волны", "zakat" to "Закат", "noch" to "Ночь", "myata" to "Мята", "custom" to "Своя")

    fun res(key: String): Int = when (key) {
        "zakat" -> R.drawable.wall_zakat
        "noch" -> R.drawable.wall_noch
        "myata" -> R.drawable.wall_myata
        else -> R.drawable.wall_volny
    }

    /** Цвет свечения часов под обои. */
    fun glow(key: String): Int = when (key) {
        "zakat" -> 0xFFFF4F8B.toInt()
        "noch" -> 0xFF22D3EE.toInt()
        "myata" -> 0xFF5EEAD4.toInt()
        else -> 0xFFC084FC.toInt()
    }
}

/** Картинка плитки приложения в стиле Apple TV: баннер 16:9 или фирменный цвет со значком. */
object Art {
    private val cache = HashMap<String, Drawable>()

    fun clear() = cache.clear()

    /** Средний цвет значка — для фона плитки, если у приложения нет баннера. */
    private fun avgColor(icon: Drawable): Int {
        val b = Bitmap.createBitmap(24, 24, Bitmap.Config.ARGB_8888)
        val c = Canvas(b)
        icon.setBounds(0, 0, 24, 24)
        icon.draw(c)
        var r = 0L; var g = 0L; var bl = 0L; var n = 0L
        for (x in 0 until 24) for (y in 0 until 24) {
            val p = b.getPixel(x, y)
            if (Color.alpha(p) < 200) continue
            val mx = maxOf(Color.red(p), Color.green(p), Color.blue(p))
            val mn = minOf(Color.red(p), Color.green(p), Color.blue(p))
            val w = 1 + (mx - mn) / 16          // насыщенные пиксели важнее серых
            r += Color.red(p) * w; g += Color.green(p) * w; bl += Color.blue(p) * w; n += w
        }
        b.recycle()
        if (n == 0L) return Color.rgb(60, 64, 80)
        val hsv = FloatArray(3)
        Color.RGBToHSV((r / n).toInt(), (g / n).toInt(), (bl / n).toInt(), hsv)
        hsv[2] = hsv[2].coerceIn(0.25f, 0.55f)   // не слишком светлый, чтобы значок читался
        return Color.HSVToColor(hsv)
    }

    fun tile(ctx: Context, a: AppEntry): Drawable {
        cache[a.pkg]?.let { return copy(ctx, it) }
        val d = a.banner ?: run {
            val w = 320; val h = 180
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(bmp)
            val bg = avgColor(a.icon)
            val hsv = FloatArray(3); Color.colorToHSV(bg, hsv)
            val top = Color.HSVToColor(floatArrayOf(hsv[0], hsv[1], (hsv[2] + 0.12f).coerceAtMost(1f)))
            val grad = android.graphics.LinearGradient(0f, 0f, 0f, h.toFloat(), top, bg, android.graphics.Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), android.graphics.Paint().apply { shader = grad })
            val s = 112
            a.icon.setBounds((w - s) / 2, (h - s) / 2, (w + s) / 2, (h + s) / 2)
            a.icon.draw(c)
            BitmapDrawable(ctx.resources, bmp)
        }
        cache[a.pkg] = d
        return copy(ctx, d)
    }

    /** Один Drawable нельзя показывать в двух местах сразу — отдаём копию. */
    private fun copy(ctx: Context, d: Drawable): Drawable =
        d.constantState?.newDrawable(ctx.resources) ?: d
}
