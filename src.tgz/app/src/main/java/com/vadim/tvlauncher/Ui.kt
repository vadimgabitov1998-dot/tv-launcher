package com.vadim.tvlauncher

import android.content.Context
import android.graphics.Color
import android.graphics.Outline
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.ViewOutlineProvider
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import kotlin.math.roundToInt

/** Все размеры задаются в пикселях макета 1920×1080 и масштабируются под экран. */
object Ui {
    var scale = 1f

    fun init(ctx: Context) {
        val dm = ctx.resources.displayMetrics
        scale = maxOf(dm.widthPixels, dm.heightPixels) / 1920f
    }

    fun px(v: Number): Int = (v.toFloat() * scale).roundToInt()
    fun pxf(v: Number): Float = v.toFloat() * scale

    fun white(a: Int): Int = Color.argb(a, 255, 255, 255)
    fun black(a: Int): Int = Color.argb(a, 0, 0, 0)

    fun font(weight: Int): Typeface = Typeface.create(Typeface.SANS_SERIF, weight, false)

    fun rect(radius: Number, fill: Int, stroke: Int = 0, strokeW: Number = 1.5): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = pxf(radius)
            setColor(fill)
            if (stroke != 0) setStroke(maxOf(1, px(strokeW)), stroke)
        }

    /** «Стекло»: полупрозрачная заливка + светлая окантовка. Размытие заранее «вшито» в обои. */
    fun glass(radius: Number, fill: Int = white(36), stroke: Int = white(60)): GradientDrawable =
        rect(radius, fill, stroke)

    fun panel(radius: Number): GradientDrawable = rect(radius, Color.argb(165, 22, 22, 38), white(55))

    /** Фон, который светлеет, когда элемент выбран пультом. */
    fun states(normal: Drawable, focused: Drawable): StateListDrawable = StateListDrawable().apply {
        addState(intArrayOf(android.R.attr.state_focused), focused)
        addState(intArrayOf(android.R.attr.state_pressed), focused)
        addState(intArrayOf(), normal)
    }

    fun glassStates(radius: Number, fill: Int = white(36), focusFill: Int = white(90)): StateListDrawable =
        states(glass(radius, fill), rect(radius, focusFill, white(200), 2.5))

    fun text(
        ctx: Context, s: CharSequence, size: Number, weight: Int = 500,
        color: Int = Color.WHITE, single: Boolean = true
    ): TextView = TextView(ctx).apply {
        text = s
        setTextSize(TypedValue.COMPLEX_UNIT_PX, pxf(size))
        typeface = font(weight)
        setTextColor(color)
        includeFontPadding = false
        if (single) {
            maxLines = 1
            ellipsize = TextUtils.TruncateAt.END
        }
    }

    fun icon(ctx: Context, res: Int, size: Number, tint: Int = Color.WHITE): ImageView = ImageView(ctx).apply {
        setImageResource(res)
        setColorFilter(tint)
        layoutParams = LinearLayout.LayoutParams(px(size), px(size))
    }

    fun roundClip(v: View, radius: Number) {
        val r = pxf(radius)
        v.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setRoundRect(0, 0, view.width, view.height, r)
            }
        }
        v.clipToOutline = true
    }

    /** Увеличение элемента при выборе пультом. */
    fun bindFocus(v: View, scaleTo: Float, lift: Number = 0, extra: ((Boolean) -> Unit)? = null) {
        v.isFocusable = true
        v.setOnFocusChangeListener { view, has ->
            view.animate()
                .scaleX(if (has) scaleTo else 1f)
                .scaleY(if (has) scaleTo else 1f)
                .translationY(if (has) -pxf(lift) else 0f)
                .setDuration(170)
                .setInterpolator(DecelerateInterpolator())
                .start()
            view.translationZ = if (has) pxf(12) else 0f
            extra?.invoke(has)
        }
    }

    fun lin(w: Int, h: Int, weight: Float = 0f) = LinearLayout.LayoutParams(w, h, weight)
    fun frame(w: Int, h: Int, gravity: Int = Gravity.NO_GRAVITY) = FrameLayout.LayoutParams(w, h, gravity)

    const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
    const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

    fun hbox(ctx: Context, gap: Number = 0): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.HORIZONTAL
        gravity = Gravity.CENTER_VERTICAL
        if (gap.toFloat() > 0f) {
            showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
            dividerDrawable = GradientDrawable().apply { setSize(px(gap), 1); setColor(0) }
        }
    }

    fun vbox(ctx: Context, gap: Number = 0): LinearLayout = LinearLayout(ctx).apply {
        orientation = LinearLayout.VERTICAL
        if (gap.toFloat() > 0f) {
            showDividers = LinearLayout.SHOW_DIVIDER_MIDDLE
            dividerDrawable = GradientDrawable().apply { setSize(1, px(gap)); setColor(0) }
        }
    }
}

fun LinearLayout.LayoutParams.m(l: Number = 0, t: Number = 0, r: Number = 0, b: Number = 0): LinearLayout.LayoutParams =
    apply { setMargins(Ui.px(l), Ui.px(t), Ui.px(r), Ui.px(b)) }

fun FrameLayout.LayoutParams.m(l: Number = 0, t: Number = 0, r: Number = 0, b: Number = 0): FrameLayout.LayoutParams =
    apply { setMargins(Ui.px(l), Ui.px(t), Ui.px(r), Ui.px(b)) }

fun View.pad(h: Number, v: Number) = setPadding(Ui.px(h), Ui.px(v), Ui.px(h), Ui.px(v))
